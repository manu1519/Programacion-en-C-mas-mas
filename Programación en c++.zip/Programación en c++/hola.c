//
//  hola.c
//  
//
//  Created by Manuel Mendoza Meza on 2/26/19.
//

#include "stdio.h"

{
    printf("Hola mundo");
    
    getch();
    
}

