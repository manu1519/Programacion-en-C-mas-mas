//Mendoza Meza Manuel Everardo
//
// Este archivo .h contiene todo las llamadas entre las clases
// bebidas y sus hijas, para desplegarlas en un men� a traves de 
// sentencias de control, ademas de contener sus propios metodos
//  
// ADP    11/05/19

#ifndef _ALMACEN_H_
#define _ALMACEN_H_

#include "C_Bebida.h"
#include "C_Natural.h"
#include "C_Mineral.h"
#include "C_Azucarada.h"

class Almacen{
      public://atributos
            Mineral est1[10];
			Natural est2[10];
            Azucarada est3[10];
            float sum_e1;
            float sum_e2;
            float sum_e3;
            float s_total;
            int indice1;
            int indice2;
            int indice3;
            
      public:// metodos
             Almacen(){};
             void menu();
             void suma_estan();
             void suma_total();
             void set_indice1(int);
             void set_indice2(int);
             void set_indice3(int);
            // void checador(string);
      };
      
    void Almacen::menu(){
           char a,b,c;
	       float Litros,Precio,Azucar;
	       int i,aux,x;
	       string Marca,Origen,Id,Sodio;
           
           for(x=0;x<10;x++){//Se encarga de limpriar todos los espacios en la estanteria para que no exista basura
           	est1[x].eliminarM();
           	est2[x].eliminarN();
           	est3[x].eliminarA();
		   }
		   
           do{
                cout<<"\nSELECCIONE UNA OPCION: "<<endl;
                cout<<"1. Agregar producto"<<endl;
                cout<<"2. Eliminar producto"<<endl;
                cout<<"3. Mostrar informacion"<<endl;
                cout<<"4. suma por estanteria"<<endl;
                cout<<"5. suma total de bebidas"<<endl;
                cout<<"6. Salir"<<endl;
                fflush(stdin);
				cin>>a;
                      
                switch(a){
                            
                            case '1':{
                                 cout<<"AGREGANDO UN PRODUCTO"<<endl;	
                                 do{
                                    cout<<"Seleccione: "<<endl;
								  	cout<<"1. Agua Mineral"<<endl;
						            cout<<"2. Agua Natural"<<endl;
						      		cout<<"3. Agua Azucarada"<<endl;
								    cout<<"4. Regresar"<<endl;
		                            fflush(stdin);
                                    cin>>b;
                                    cout<<endl;//deja un espacio
                                    switch (b){
                                                case '1':{//MINERAL
												if(indice1<10){
                                                	for(int i=0;i<10;i++){
                                                		if(est1[i].get_ID()==""){
                                                		aux=i;
                                                		break;
														}
												    }
												    
												    cout<<"Agua Mineral"<<endl; 
                                                    cout<<"Escribe el identificador del producto: ";
                                                    fflush(stdin);
				                                    getline(cin,Id);
				                                    
				                                    for(int i=0;i<10;i++){
													
													    if(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID()){
                                                     	  do{
                                                     	  cout<<"Ya ha registrado una bebida con el mismo ID"<<endl;
														  cout<<"Por favor utilizar un ID diferente: ";
                                                     	  fflush(stdin);
														  cin>>Id;
													      }while(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID());
                                                     	}
														break;
													 }
													
												
													cout<<"Escribe la cantidad de litros: ";
                                                    cin>>Litros;
                                                    cout<<"Escribe el precio (MXN): $";
                                                    cin>>Precio;
                                                    cout<<"Escribe la marca: ";
                                                    fflush(stdin);
				                                    getline(cin,Marca);
                                                    cout<<"Escribe el origen: "; 
                                                    fflush(stdin);
				                                    getline(cin,Origen);
                                                	// est1[indice1].agregarM(_id,_litros,_precio,_marca,_origen);
                                                	est1[aux].agregarM(Id,Litros,Precio,Marca,Origen);
                                                	indice1++;//est1[aux].set_indice1(indice1)
                                                	cout<<"Los datos se han registrado correctamente"<<endl;
                                                	cout<<endl;
											    }
                                                
                                                else {
												cout<<"La estanteria esta llena"<<endl;
												}
                                                break;
                                                }
                                                
                                                case '2':{//NATURAL
												if(indice2<10){
                                                	for(int i=0;i<10;i++){
                                                		if(est2[i].get_ID()==""){
                                                		aux=i;
                                                		break;
														}
													}
													cout<<"Agua natural"<<endl;
                                                    cout<<"Escribe el identificador del producto: ";
                                                    fflush(stdin);
				                                    getline(cin,Id);
				                                    
				                                    for(int i=0;i<10;i++){
													
													    if(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID()){
                                                     	  do{
                                                     	  cout<<"Ya ha registrado una bebida con el mismo ID"<<endl;
														  cout<<"Por favor utilizar un ID diferente: ";
                                                     	  fflush(stdin);
														  cin>>Id;
													      }while(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID());
                                                     	}
														break;
													 }
													 
													 
													cout<<"Escribe la cantidad de litros: ";
                                                    cin>>Litros;
                                                    cout<<"Escribe el precio (MXN): $";
                                                    cin>>Precio;
                                                    cout<<"Escribe la marca: ";
                                                    fflush(stdin);
				                                    getline(cin,Marca);
                                                    cout<<"Contiene sodio? (Si/No): ";
												    fflush(stdin);
												    getline(cin,Sodio);
                                                	est2[aux].agregarN(Id,Litros,Precio,Marca,Sodio);
                                                    indice2++;
                                                    cout<<"Los datos se han registrado correctamente"<<endl;
                                                    cout<<endl;
												}
                                                
                                                else {
												cout<<"La estanteria esta llena"<<endl;
												}
                                                break;
                                                }
                                                
                                                case '3':{//AZUCARADA
											    if(indice3<10){
                                                	for(int i=0;i<10;i++){
                                                		if(est3[i].get_ID()==""){
                                                		aux=i;
                                                		break;
														}
													}
													 
													cout<<"Bebidas azucaradas"<<endl;
													cout<<"Escribe el identificador del producto: ";
                                                    fflush(stdin);
				                                    getline(cin,Id);
				                                    
				                                    for(int i=0;i<10;i++){
													
													    if(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID()){
                                                     	  do{
                                                     	  cout<<"Ya ha registrado una bebida con el mismo ID"<<endl;
														  cout<<"Por favor utilizar un ID diferente: ";
                                                     	  fflush(stdin);
														  cin>>Id;
													      }while(Id==est1[i].get_ID()||Id==est2[i].get_ID()||Id==est3[i].get_ID());
                                                     	}
														break;
													 }
													 
				                                    
													cout<<"Escribe la cantidad de litros: ";
                                                    cin>>Litros;
                                                    cout<<"Escribe el precio (MXN): $";
                                                    cin>>Precio;
                                                    cout<<"Escribe la marca: ";
                                                    fflush(stdin);
				                                    getline(cin,Marca);
                                                    cout<<"Escriba el porcentaje de azucar: %";
				                   					cin>>Azucar;
                                                	est3[aux].agregarA(Id,Litros,Precio,Marca,Azucar);
                                                	indice3++;
                                                	cout<<"Los datos se han registrado correctamente"<<endl;
                                                	cout<<endl;
												}
                                                
                                                else{
												cout<<"La estanteria esta llena"<<endl;
												}
                                                break;
                                                }
                                                
                                                case'4':
                                                	break;
                                                
                                            	default: //si el usuario introduce un caracter que no sea 1, 2, 3 o 4  mandara un mensaje
                                            	cout<<"Opcion invalida, introduzca una opcion valida"<<endl;
                                            	
                                    };                 
                                  }while(b!='4');
                                     
                            break;
                            }
                            
							case '2':
								cout<<"ELIMINAR UN PRODUCTO MEDIANTE ID"<<endl;
								cout<<"Escriba el ID (solo numeros) del producto que desea Eliminar: ";
								cin>>Id;
								for(int i=0;i<10;i++){  //se entra en un ciclo for que evalue cada objeto de cada subclase
		
									if(Id==est1[i].get_ID()){    //si la cadena introducida con el usuario es igual al atributo del identificador del respectivo objeto se llama al metodo eliminar
									est1[i].eliminarM();
									cout<<"El producto con ID "<<Id<<" ha sido eliminado de Aguas Minerales"<<endl;
				                    }
				                    else{
									if(Id==est2[i].get_ID()){
									est2[i].eliminarN();
									cout<<"El producto con ID "<<Id<<" ha sido eliminado de Aguas Naturales"<<endl;
									}	
									else{
									if(Id==est3[i].get_ID()){
									est3[i].eliminarA();
									cout<<"El producto con ID "<<Id<<" ha sido eliminado de Bebidas Azucaradas"<<endl;
									}
									else 
									cout<<"Aun no ha registrado ningun producto. Regrese al menu principal y agregue uno"<<endl;
									break;
									}
									}
									
									
								}
											
								break;
								
							case '3':
								cout<<"INFORMACION DE LOS PRODUCTOS AGREGADOS"<<endl<<endl;
								cout<<"CARGANDO INFORMACION DE LA BEBIDA..."<<endl;								
								cout<<endl<<"Los productos en el estante de Agua Mineral son: "<<endl<<endl;
								
								for(int i=0;i<10;i++){
									if(est1[i].get_ID()=="")
									cout<<"Bebida No."<<i+1<<": ESPACIO VACIO"<<endl;
									else
									{
									cout<<"Bebida No."<<i+1<<":"<<endl;
									est1[i].mostrarM();
									cout<<endl;
									}
								}
								
								cout<<endl<<"Los productos en el estante de Agua Natural son: "<<endl<<endl;
								for(int j=0;j<10;j++){
									
									if(est2[j].get_ID()=="")
									cout<<"Bebida No."<<j+1<<": ESPACIO VACIO"<<endl;
									else
									{
									cout<<"Bebida No."<<j+1<<":"<<endl;
									est2[j].mostrarN();
									cout<<endl;
									}
								}
								
								cout<<endl<<"Los productos en el estante de Bebidas Azucaradas son: "<<endl<<endl;
								for(int k=0;k<10;k++){
									
									if(est3[k].get_ID()=="")
									cout<<"Bebida No."<<k+1<<": ESPACIO VACIO"<<endl;
									else
									{
									cout<<"Bebida No."<<k+1<<":"<<endl;
									est3[k].mostrarA();
									cout<<endl;
									}
								}
								break;
							
							case '4':
								cout<<"\nLa suma de cada estanteria es: "<<endl;
								suma_estan();
								break;
								
							case '5':
								cout<<"\nLa suma total de los productos es: ";
								suma_total();
								break;
							
							case '6':
								break;
								
							default://si el usuario introduce un caracter que no sea 1, 2, 3, 4, 5 o 6  mandara un mensaje
								cout<<"Opcion invalida, introduzca una opcion valida"<<endl;
				           
                };             
            }while(a!='6');
    };
           
           
           
	void Almacen::set_indice1(int d){
	indice1=d;
	};
	
	void Almacen::set_indice2(int e){
	indice2=e;
	};
	
	void Almacen::set_indice3(int f){
	indice3=f;
	};

	void Almacen::suma_estan(){
	sum_e1=0;
	sum_e2=0;
	sum_e3=0;
	for(int i=0;i<10;i++){
		sum_e1=sum_e1+est1[i].get_precio();
		sum_e2=sum_e2+est2[i].get_precio();
		sum_e3=sum_e3+est3[i].get_precio();
	}
	if(sum_e1==0){
		cout<<"Estanteria 1: ";
		cout<<"Aun no ha registrado ninguna bebida..."<<endl;
	}
	else
	    cout<<"Estanteria 1: $"<<sum_e1<<endl;
	if(sum_e2==0){
		cout<<"Estanteria 2: ";
		cout<<"Aun no ha registrado ninguna bebida..."<<endl;
	}
	else
	    cout<<"Estanteria 2: $"<<sum_e2<<endl;
	if(sum_e3==0){
		cout<<"Estanteria 3: ";
		cout<<"Aun no ha registrado ninguna bebida..."<<endl;
	}
	else
	    cout<<"Estanteria 3: $"<<sum_e3<<endl;
	};
	
	void Almacen::suma_total(){
	s_total=0;
	for(int i=0;i<10;i++){
	  s_total=s_total+est1[i].get_precio();
	  s_total=s_total+est2[i].get_precio();
	  s_total=s_total+est3[i].get_precio();
	}
	if(s_total==0){
		cout<<"Aun no ha registrado ninguna bebida..."<<endl;
	}
	else
	    cout<<"$"<<s_total<<endl;
	
	};
#endif
