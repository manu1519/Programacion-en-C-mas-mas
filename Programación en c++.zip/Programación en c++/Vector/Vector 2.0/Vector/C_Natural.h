//Mendoza Meza Manuel Everardo
//
// Esta parte del programa permite visualizar los metodos 
// y atributos de la clase agua natural
//  
// ADP    11/05/19 

#ifndef _C_NATURAL_H_
#define _C_NATURAL_H_
#include "C_Bebida.h"

class Natural: public Bebida{
      public:
      string sodio;
      
      public:
      Natural(){};//Constructor de la subclase mineral
      void agregarN(string, float, float, string, string);
      void eliminarN();
      void set_sodio(string);
      string get_sodio();
      void mostrarN();
};

void Natural::agregarN(string __ID, float __litros, float __precio, string __marca, string __sodio){
  set_ID(__ID);
  set_litros(__litros);
  set_precio(__precio);
  set_marca(__marca);
  set_sodio(__sodio);//sodio=__sodio;  
}

void Natural::eliminarN(){
  set_ID("");
  set_litros(0);
  set_precio(0);
  set_marca("");
  set_sodio("");
};
           
void Natural::set_sodio(string _sodio){
  sodio=_sodio;
};

string Natural::get_sodio(){
  return sodio;
};

void Natural::mostrarN(){
	mostrarB();
	cout<<get_sodio()<<" contiene sodio"<<endl;
};
#endif
