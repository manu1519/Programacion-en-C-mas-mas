//	Mendoza Meza Manuel E.
//	ADP
//	14/05/2019
//	Programa que permite ocupar la libreria vector
//	para mostrar un arreglo con datos que ingrese el usuario


#include <iostream>
#include "C_Natural.h"
#include <vector>
using namespace std;

int main() {
	
	vector<Natural>datos;
	Natural aux;
	
	//declarar el vector
	for (int i=0;i<2;i++){
	
		cout<<"Dame un ID"<<endl;
		cin>>aux.ID;
		cout<<"Dame la marca"<<endl;
		cin>>aux.marca;
		cout<<"Dame los litros"<<endl;
		cin>>aux.litros;
		cout<<"Dame el precio"<<endl;
		cin>>aux.precio;
		cout<<"tiene sodio"<<endl;
		cin>>aux.sodio;
		
		datos.push_back(aux);
}

		//mostrar los datos del vector
	cout<<endl;
	for (int i=0;i<datos.size();i++){
		cout<<datos[i].ID<<endl;
		cout<<datos[i].marca<<endl;
		cout<<datos[i].litros<<endl;
		cout<<datos[i].precio<<endl;
		cout<<datos[i].sodio<<endl;
	}
	/*
		//borrar los elementos de un vector
		
	datos.erase(datos.begin()+2);
	
	cout<<endl;
	
	for (int i=0;i<datos.size();i++){
		cout<<datos[i]<<endl;
	}
	
	datos.erase(datos.begin()+3);
	
	cout<<endl;
	
	for (int i=0;i<datos.size();i++){
		cout<<datos[i]<<endl;
	}
	*/
	system("pause");
	return 0;
}


