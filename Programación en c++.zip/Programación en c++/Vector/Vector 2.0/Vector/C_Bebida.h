//Mendoza Meza Manuel Everardo
//
// Esta parte del programa permite visualizar los metodos 
// y atributos de la clase bebidas, en la cual aparecen
// los datos que se anidadaran posteriormente a las subclases
//  
// ADP    11/05/19
  
#ifndef _C_BEBIDA_H_
#define _C_BEBIDA_H_

#include <iostream>
#include <string>
using namespace std;

class Bebida{
      
      public://atributos
      string ID;
      float litros;
      float precio;
      string marca;
      
      public://metodos
      Bebida (){};//constructor vacio
      void set_ID(string);
      void set_litros(float);
      void set_precio(float);
      void set_marca(string);
      string get_ID();
      float get_litros();
      float get_precio();
      string get_marca();
      void mostrarB();
};

void Bebida::set_ID(string _ID){
  ID=_ID;
};

void Bebida::set_litros(float _litros){
  litros=_litros;
};

void Bebida::set_precio(float _precio){
  precio=_precio;
};

void Bebida::set_marca(string _marca){
  marca=_marca;
};

string Bebida::get_ID(){
  return ID;
};

float Bebida::get_litros(){
  return litros;
};

float Bebida::get_precio(){
  return precio;
};

string Bebida::get_marca(){
  return marca;
};

void Bebida::mostrarB(){
  cout<<"El ID de la bebida es: "<<get_ID()<<endl;
  cout<<"La cantidad de litros de la bebida es: "<<get_litros()<<"L"<<endl;
  cout<<"El precio de la bebida es: $"<<get_precio()<<"MXN"<<endl;
  cout<<"La marca de la bebida es: "<<get_marca()<<endl;
  };
#endif
