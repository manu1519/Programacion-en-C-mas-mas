/*
Los principales responsables de la ejecuci�n del programa son los punteros (*arr1,*arr2,etc.).
En caso de que quieras cambiar el nombre de uno, cambialo en todo el programa.
Ej, Si quieres renombrar a "arr1" como "Bahena", todos los "arr1" del programa deber�n ser llamados "Bahena".
Recuerda solo cambiar el nombre, dejando el * como esta.
En main hay dos arreglos con n�meros ddefinidos en ellos (arreglo1[]={2,7,7,4,3},arreglo2[]={3,6,2,3,7}).
Cambia esos numeros por otros, el programa funciona igual con n�meros distintos.
Un vez ejecutado correctamente, toma una captura de la ventana de comandos y anexala al reporte de pr�tica.
Finalmente, no seas imb�cil y borra estos comentarios xd.
Muchas gracias por tu apoyo y suerte en el resto de tus materias ;v
*/
#include <stdio.h>
#include <stdlib.h>

void fun1(int *M)
{
int i;
char div[]="-------------------------------";
printf("Funcion i:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",M[i]);
 }
printf("\n%s\n",div);
}

void fun2(int *M, int *l, int *p)
{
int i,res;
printf("Funcion ii:\nArreglo original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",M[i]);
 }
printf("\nArreglo No. 2:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",l[i]);
 }
printf("\nSuma de los dos arreglos:\n");
 for(i=0;i<5;i++)
 {
 p[i]=M[i]+l[i];
 }
}

void fun3(int *M, int *arr4)
{
int i;
char div[]="-------------------------------";
printf("Funcion iii:\nArreglo original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",M[i]);
 arr4[4-i]=M[i];
 }
printf("\nArreglo invertido:\n");
for(i=0;i<5;i++)
 {
 printf("%d\t",M[4-i]);
 }
printf("\n%s\n",div);
}

void fun4(int *M, char *arr5)
{
int i;
printf("Funcion iv:\nArreglo original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",M[i]);
 }
printf("\nArreglo par o impar:\n");
 for(i=0;i<5;i++)
 {
  if(M[i]%2==0)
  {
  arr5[i]='P';
  }
  else
  {
  arr5[i]='I';
  }
 }
}

int main(int argc, char *argv[])
{
int arreglo1[]={9,4,3,5,1},arreglo2[]={7,5,4,5,6},arreglo3[5],arreglo4[5],i;
char arreglo5[5];
int *M,*l,*p,*arr4;
char *arr5;
char div[]="-------------------------------";
M=&arreglo1;
l=&arreglo2;
p=&arreglo3;
arr4=&arreglo4;
arr5=&arreglo5;
fun1(M);
fun2(M,l,p);
 for(i=0;i<5;i++)
 {
 printf("%d\t",arr3[i]);
 }
printf("\n%s\n",div);
fun3(M,arr4);
fun4(M,arr5);
 for(i=0;i<5;i++)
 {
 printf("%c\t",arr5[i]);
 }
printf("\n%s\n",div);
system("PAUSE");
return 0;
}
