//Mendoza Meza Manuel Everardo
//
// Esta parte del programa permite visualizar los metodos 
// y atributos de la clase agua azucarada
//  
// ADP    11/05/19

#ifndef _C_AZUCARADA_H_
#define _C_AZUCARADA_H_
#include "C_Bebida.h"

class Azucarada: public Bebida{
      private://atributos
      float azucar;
      
      public:
      Azucarada(){};//metodosl
      void agregarA(string, float, float, string, float);
      void eliminarA();
      void set_azucar(float);
      float get_azucar();
      void mostrarA();
};

void Azucarada::agregarA(string __ID, float __litros, float __precio, string __marca, float __azucar){
  set_ID(__ID);
  set_litros(__litros);
  set_precio(__precio);
  set_marca(__marca);
  set_azucar(__azucar);//azucar=_azucar
};
      
void Azucarada::eliminarA(){
  set_ID("");
  set_litros(0);
  set_precio(0);
  set_marca("");
  set_azucar(0);
};

void Azucarada::set_azucar(float _azucar){
  azucar=_azucar;
};

float Azucarada::get_azucar(){
  return azucar;
};

void Azucarada::mostrarA(){
	mostrarB();
	cout<<"El contenido en porcentaje de azucar es: %"<<get_azucar()<<endl;
};
#endif
