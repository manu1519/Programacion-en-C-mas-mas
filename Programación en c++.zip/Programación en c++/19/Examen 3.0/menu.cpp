//Mendoza Meza Manuel Everardo
//
// Este archivo contiene al main principal
// con el cual se hace llamado a todos los headers
// que contienen el menu y las bebidas
//  
// ADP    11/05/19

#include "C_Almacen.h"

int main(){

	Almacen almacen1;
	almacen1.set_indice1(0);
	almacen1.set_indice2(0);
	almacen1.set_indice3(0);
	almacen1.menu();
	cin.ignore();
	return 0;

};
