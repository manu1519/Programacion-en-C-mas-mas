//Mendoza Meza Manuel Everardo
//
// Esta parte del programa permite visualizar los metodos 
// y atributos de la clase agua mineral
//  
// ADP    11/05/19

#ifndef _C_MINERAL_H_
#define _C_MINERAL_H_
#include "C_Bebida.h"

class Mineral: public Bebida{
      private:
      string origen;
      
      public:
      Mineral(){};//Constructor de la subclase mineral
      void agregarM(string, float, float, string, string);
      void eliminarM();
      void set_origen(string);
      string get_origen();
      void mostrarM();
};

void Mineral::agregarM(string __ID, float __litros, float __precio, string __marca, string __origen){
  set_ID(__ID);
  set_litros(__litros);
  set_precio(__precio);
  set_marca(__marca);
  set_origen(__origen);//origen=__origen; 
}

void Mineral::eliminarM(){
  set_ID("");
  set_litros(0);
  set_precio(0);
  set_marca("");
  set_origen("");
};
           
void Mineral::set_origen(string _origen){
  origen=_origen;
};

string Mineral::get_origen(){
  return origen;
};

void Mineral::mostrarM(){
	mostrarB();
	cout<<"El origen del agua mineral es: "<<get_origen()<<endl;
};
#endif
