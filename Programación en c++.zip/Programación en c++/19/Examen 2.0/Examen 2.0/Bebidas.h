//
//  Bebidas.h
//  Examen 2.0
//
//  Created by Manuel Mendoza Meza on 5/8/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Bebidas_h
#define Bebidas_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>


using namespace std;

class Bebida{
private:    //-------Atributos
    string ID;
    float CantL;
    float Preci;
    string Marc;
    
public:     //-------Metodos
    int  est_1[10];
    int  est_2[10];
    int  est_3[10];
    Bebida(){};
    float get_CantL();
    float get_Preci();
    string get_Marc();
    string get_ID();
    void set_ID(string);
    void set_CantL(float);
    void set_Preci(float);
    void set_Marc(string);
    void Mostrarinfo();
};
//---------------------------------------Clase Agua natural

class Aguan : public Bebida{
private:                //------Atributos
    char Sodio;
public:                 //------Metodos
    Aguan(){};
    void agregar(string, float, float, string, char);
    void eliminar();
    void mostrar();
    int get_Sodio();
    void set_Sodio(char);
};
//--------getters
int Aguan::get_Sodio(){
    return Sodio;
};
//--------setters

void Aguan::set_Sodio(char S){
    cout<<"Coloque: "<<endl<<"0. Su bebida contiene sodio"<<endl<<"1. Su bebida no contiene sodio"<<endl;
    cin>>S;
};

void Aguan::agregar(string x, float Lt, float pre, string M, char so){
    set_Sodio(so);
    set_ID(x);
    set_CantL(Lt);
    set_Preci(pre);
    set_Marc(M);
};
void Aguan::eliminar(){
    set_Sodio(' ');
    set_ID(" ");
    set_CantL(0);
    set_Preci(0);
    set_Marc(" ");
};
void Aguan::mostrar(){
    cout<<"Sodio: "<<get_Sodio()<<endl;
    cout<<"ID: "<<get_ID()<<endl;
    cout<<"Litros: "<<get_CantL()<<endl;
    cout<<"Precio: "<<get_Preci()<<endl;
    cout<<"Marca: "<<get_Marc()<<endl;
    
};

//---------------------fin agua natural

//-------------------------agua Mineral

class Aguamin : public Bebida
{
private:            //-----atributos
    string Manantial;
public:             //-----metodos
    Aguamin(){};
    void agregar1(string, float, float, string, string);
    void eliminar1();
    void mostrar1();
    string get_Manantial();
    void set_Manantial(string);
};
void Aguamin::agregar1(string x, float Lt, float pre, string M, string man){
    set_Manantial(man);
    set_ID(x);
    set_CantL(Lt);
    set_Preci(pre);
    set_Marc(M);
};
void Aguamin::eliminar1(){
    set_Manantial(" ");
    set_ID(" ");
    set_CantL(0);
    set_Preci(0);
    set_Marc(" ");
};
void Aguamin::mostrar1(){
    cout<<"Manantial: "<<get_Manantial()<<endl;
    cout<<"ID: "<<get_ID()<<endl;
    cout<<"Litros: "<<get_CantL()<<endl;
    cout<<"Precio: "<<get_Preci()<<endl;
    cout<<"Marca: "<<get_Marc()<<endl;
    
};
string Aguamin::get_Manantial(){
    return (Manantial);
};

void Aguamin::set_Manantial(string){
    string X;
    cout<<"Coloque el manantial o en su defecto donde fue extraida el agua"<<endl;
    cin>>X;
};
//------------------------fin de agua mineral
//-----------------------------agua Azucarada

class AguaA : public Bebida{
private:            //-----atributos
    float Azucar;
public:             //-----metodos
    AguaA(){};
    void agregar2(string, float, float, string, float);
    void eliminar2();
    void mostrar2();
    float get_Azucar();
    void set_Azucar(float);
};
void AguaA::agregar2(string x, float Lt, float pre, string M, float azu){
    set_Azucar(azu);
    set_ID(x);
    set_CantL(Lt);
    set_Preci(pre);
    set_Marc(M);
};
void AguaA::eliminar2(){
    set_Azucar(0);
    set_ID(" ");
    set_CantL(0);
    set_Preci(0);
    set_Marc(" ");
};
void AguaA::mostrar2(){
    cout<<"Manantial: "<<get_Azucar()<<endl;
    cout<<"ID: "<<get_ID()<<endl;
    cout<<"Litros: "<<get_CantL()<<endl;
    cout<<"Precio: "<<get_Preci()<<endl;
    cout<<"Marca: "<<get_Marc()<<endl;
    
};
float AguaA::get_Azucar(){
    return (Azucar);
};

void AguaA::set_Azucar(float g){
    
    cout<<"Ingrese el porcentaje de azucar en su bebida "<<endl;
    cin>>g;
    
};

//-----------------------------fin de agua azucarada
//---------------------getters
float Bebida::get_CantL(){
    return CantL;
};
float Bebida::get_Preci(){
    return Preci;
};
string Bebida::get_Marc(){
    return Marc;
};
string Bebida::get_ID(){
    return ID;
};
//----------------------setters
void Bebida::set_CantL(float b){
    CantL=b;
};
void Bebida::set_Preci(float C){
    Preci=C;
};
void Bebida::set_Marc(string D){
    Marc=D;
};
void Bebida::set_ID(string I){
    ID=I;
};
void Bebida::Mostrarinfo(){
    
};

//--------------------------------------------almacen

#endif /* Bebidas_h */
