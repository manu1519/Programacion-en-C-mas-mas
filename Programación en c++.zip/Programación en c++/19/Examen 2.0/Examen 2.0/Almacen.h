//
//  Almacen.h
//  Examen 2.0
//
//  Created by Manuel Mendoza Meza on 5/8/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Almacen_h
#define Almacen_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "Bebidas.h"
using namespace std;

class Almacen {
    
public:
    
    Bebida *obj1;
    int IndiceAn;
    int IndiceAm;
    int IndiceAa;
    int sum_e1;
    int sum_e2;
    int sum_e3;
    int S_total;
public:
    Almacen(){};
    Almacen(Bebida *objeto1){objeto1=obj1;};
    void menu();
    float suma_estan();
    void suma_total();
};

void Almacen::menu(){
    char opc, opc2;
    string marc, ID, origen;
    float precio, litro;
    do{
        cout<<"Bienvenido a Almacenes MTC"<<endl;
        cout<<"Seleccione una opción: "<<endl;
        cout<<"A. Alta"<<endl;
        cout<<"B. Baja"<<endl;
        cout<<"C. Mostrar"<<endl;
        cout<<"D. Suma estanteria"<<endl;
        cout<<"E. suma total"<<endl;
        cin>>opc;
        switch (opc) {
            case 'A':
            case 'a':
                do{
                    cout<<"1. Agua Natural"<<endl;
                    cout<<"2. Agua Mineral"<<endl;
                    cout<<"3. Agua Azucarada"<<endl;
                    cout<<"4. Regresar"<<endl;
                    cin>>opc2;
                    switch (opc2) {
                        case '1':
                            
                            cout<<"Digite su marca"<<endl;
                            cin>>marc;
                            cout<<"Digite su precio"<<endl;
                            cin>>precio;
                            cout<<"Digite la cantidad de litros"<<endl;
                            cin>>litro;
                            cout<<"Digite un ID"<<endl;
                            cin>>ID;
                            
                            obj1->est_1[IndiceAn];
                            obj1->est_1[sum_e1];
                            obj1->est_1[S_total];
                            
                            break;
                            
                        case '2':
                            
                            cout<<"Digite su marca"<<endl;
                            cin>>marc;
                            cout<<"Digite su precio"<<endl;
                            cin>>precio;
                            cout<<"Digite la cantidad de litros"<<endl;
                            cin>>litro;
                            cout<<"Digite un ID"<<endl;
                            cin>>ID;
                            
                            obj1->est_2[IndiceAm];
                            IndiceAm++;
                            obj1->est_2[sum_e2];
                            sum_e2++;
                            obj1->est_2[S_total];
                            S_total++;
                            break;
                            
                        case '3':
                            
                            cout<<"Digite su marca"<<endl;
                            cin>>marc;
                            cout<<"Digite su precio"<<endl;
                            cin>>precio;
                            cout<<"Digite la cantidad de litros"<<endl;
                            cin>>litro;
                            cout<<"Digite un ID"<<endl;
                            cin>>ID;
                            
                            obj1->est_3[IndiceAa];
                            IndiceAa++;
                            obj1->est_3[IndiceAa];
                            obj1->est_3[S_total];
                            break;
                        case '4':
                            return menu();
                            break;
                        default:
                            break;
                    }
                }while (opc2 != 4);
                
            case 'B':
            case 'b':
                
                break;
            case 'C':
            case 'c':
                
                break;
            case 'D':
            case 'd':
                int sum, x, opi;
                cout<<"Que estanteria desea calcular"<<endl;
                cout<<"1. Agua Natural"<<endl;
                cout<<"2. Agua Mineral"<<endl;
                cout<<"3. Agua Azucarada"<<endl;
                cin>>opi;
                switch (opi) {
                    case '1':
                        
                        sum = obj1->est_1[0];
                        
                         for (x=0; x<10; x++) {
                        sum = sum + obj1->est_1[x];
                }
                        cout<<"La suma de esta estantería es: "<<sum<<endl;
                        
                        break;
                        
                    case '2':
                        
                        sum = obj1->est_2[0];
                        
                        for (x=0; x<10; x++) {
                            sum = sum + obj1->est_2[x];
                        }
                        cout<<"La suma de esta estantería es: "<<sum<<endl;
                        break;
                   
                    case '3':
                        
                        sum = obj1->est_3[0];
                        
                        for (x=0; x<10; x++) {
                            sum = sum + obj1->est_3[x];
                        }
                        cout<<"La suma de esta estantería es: "<<sum<<endl;
                        break;
                        
                    default:
                        break;
                }
        
                break;
            case 'E':
            case 'e':
                int sumaT;
                sumaT= obj1->est_1[IndiceAn] + obj1->est_1[IndiceAm] + obj1->est_1[IndiceAa];
                cout<<"La suma de todos los productos es: "<<sumaT<<endl;
                break;
            default:
                break;
        }
    }while(opc != ' ');
    
};

#endif /* Almacen_h */
