//
//  main.cpp
//  Examen 2.0
//
//  Created by Manuel Mendoza Meza on 5/8/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>
#include "Bebidas.h"
#include "Almacen.h"
int main() {
    
    Bebida Beb;
    Beb.Mostrarinfo();
    Almacen alama;
    alama.menu();
    
    system("pause");
    return 0;
}
