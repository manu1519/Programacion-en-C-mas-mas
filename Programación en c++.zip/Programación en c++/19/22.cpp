#include "CMenu.h"
int main(){
	CCuenta objeto(0,.02);
	CMenu obj_menu(&objeto);
	obj_menu.menu();
	system("Pause");
	return 0;
}
