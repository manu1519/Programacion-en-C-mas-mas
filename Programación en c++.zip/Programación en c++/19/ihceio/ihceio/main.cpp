//
//  main.cpp
//  ihceio
//
//  Created by Manuel Mendoza Meza on 4/9/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
