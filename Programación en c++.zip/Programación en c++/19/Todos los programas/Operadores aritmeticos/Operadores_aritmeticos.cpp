//  Mendoza Meza Manuel Everardo
//
//
//
//  Analisis y dise�o de programas
//  Programa: Operadores Aritm�ticos


#include <iostream>
#include <stdlib.h>
#include <math.h>
using namespace std;

int main(){
    float X,Y,Re=0, Resi=0;
	char O;
    
	cout<<"Elije la opcion que desee:"<<endl;
	cout<<"1. Suma"<<endl;
	cout<<"2. Resta"<<endl;
	cout<<"3. Multiplicacion"<<endl;
	cout<<"4. Division"<<endl;
	cin>>O;
    
	switch(O){
		case '1':
			cout<<"Digite X numero: "<<endl;
            cin>>X;
            
			cout<<"Digite el segundo numero: ";
            cin>>Y;
            cout<<endl;
            
			Re= X+Y;
            cout<<"El resultado es: "<<Re<<endl;
            
			break;
		case '2':
			cout<<"Digite X numero: "<<endl;
            cin>>X;
            
			cout<<"Digite Y numero: "<<endl;
            cin>>Y;
			
            Re= X-Y;
			cout<<"El resultado es: "<<Re<<endl;
            
			break;
		case '3':
			cout<<"Digite X numero: "<<endl;
            cin>>X;
            
            cout<<"Digite Y numero: "<<endl;
            cin>>Y;
            
			Re= X*Y;
			cout<<"El resultado es: "<<Re<<endl;
            
			break;
		case '4':
            int X,Y;
            cout<<"Digite X numero: "<<endl;
            cin>>X;
            
            cout<<"Digite Y numero: "<<endl;
            cin>>Y;
            
			Re= X / Y;
			Resi = X % Y;
			cout<<"El resultado es: "<<Re<<endl;
			cout<<"El residuo es:"<<Resi<<endl;
			break;
		default:
			cout<<"Opcion invalida"<<endl;
	}
system("PAUSE");
	return 0;
}
