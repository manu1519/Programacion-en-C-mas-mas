//  Mendoza Meza Manuel Everardo
//
//  Programa que detecta si dos n�meros son iguales, uno es mayor que otro y
//  viceversa
//
//  Analisis y dise�o de programas
//  Programa: Numero mayor


#include <iostream>
#include <stdlib.h>

using namespace std;

int main(){
    
    float NumA;
    float NumB;
	
	cout<<"Digite el primer numero:"<<endl;
	cin>>NumA;
	cout<<"Digite el primer numero:"<<endl;
	cin>>NumB;
	
	if(NumA==NumB){                     //Con este if se logra identificar si los numeros introducidos son iguales
        
	cout<<"El numero"<<NumA<<" es igual que"<<NumB<<endl;
        
	}
    
    if(NumA>NumB){                      //se analiza con un if para dectectar si un numero es mayor que otro
        
	cout<<"El numero "<<NumA<<" es mayor que "<<NumB<<endl;
	}
    
    else{
	cout<<"El numero "<<NumB<<" es mayor que "<<NumA<<endl;
	}
	
    system("pause");
	return 0;
}
