//  Mendoza Meza Manuel Everardo
//
//  Programa que despliegua el mensaje Hola mundo
//  ocupande del lenguaje C++
//
//  Analisis y dise�o de programas
//  Programa: Hola mundo

#include <iostream>
#include <stdlib.h>

using namespace std;

int main(){
	cout<<"Hola mundo"<<endl;
	
system("PAUSE");
	return 0;
}
