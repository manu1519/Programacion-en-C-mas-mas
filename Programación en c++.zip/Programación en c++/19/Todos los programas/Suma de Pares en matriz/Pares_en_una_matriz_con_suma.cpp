//  Mendoza Meza Manuel Everardo
//
//  programa que permite generar un arreglo de dos dimensiones
//  y determina si los numeros ingresados son pares
//
//  Analisis y dise�o de programas
//  Programa: suma de pares en una matriz



#include <iostream>
#include <stdlib.h>

using namespace std;

int main(){
    
	int M[100][100],x,y;
	int i, j;
	int S=0;
    
	cout<<"Filas:";
	cin>>x;
    
	cout<<"Columnas:";
	cin>>y;
	
	for ( i=0; i<x; i++){
		for ( j=0; j<y; j++){
            
            cout<<"Digite un numero ["<<i<<"]["<<j<<"]: "<<endl;
			cin>>M[i][j];
            
		}
	}
	
    cout<<"Sus numeros son: "<<endl;
    
	for ( i=0; i<x; i++){
		for ( j=0; j<y; j++){
            
            cout<<M[i][j]<<endl;
            
		}
	}
	
	for ( i=0; i<x; i++){
		for ( j=0; j<y; j++){
            
		if (M[i][j] % 2 == 0){
            
		S+=M[i][j];
            cout<<endl;
            
			}
		}
	}
	
cout<<"El resultado es:"<<S<<endl;
    
system("PAUSE");
	return 0;
}
