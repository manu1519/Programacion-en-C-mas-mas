//  Mendoza Meza Manuel Everardo
//
//  Programa que permite hacer una suma de x numeros contenidos en un arreglo
//
//  Analisis y dise�o de programas
//  Programa: Hola mundo



#include <iostream>
#include <stdlib.h>

using namespace std;

int main(){
    
	int x[50];
	int i,V,Re=0;
    
	cout<<"Digite los numeros que quiera sumar:";
	cin>>V;
    
for( i=1; i<=V; i++){
        
        cout<<"Digite el numero "<<i<<":"<<endl;
		cin>>x[i];
        
		Re= Re + x[i];
        
}
    
	cout<<"El resultado es:"<<Re<<endl;
    
system("PAUSE");
	return 0;
}
