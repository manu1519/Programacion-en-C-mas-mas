//
//  clase hoy.hpp
//  Class
//
//  Created by Manuel Mendoza Meza on 4/4/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef _CCUENTAGS_H_
#define _CCUENTAGS_H_
#include <iostream>
using namespace std;
class CcuentaGS{
    
private:                                                                           //ambito(publico privado protegido)
    float saldo;
    float interes;
    
public:
    CcuentaGS(){};
    void deposito(float monto);
    void retirar(float monto);
    void consultar();                                                                //() es parametro de entrada
    float get_saldo();
    void set_saldo(float monto);
    float get_interes();
    void set_interes(float monto);
    void negativo();
    void intereses();
    //constructores son los iniciadores de las variables es llamado igual de la cclase, no tiene un tipo
    CcuentaGS(float monto_ini, float inte);
};

float CcuentaGS::get_saldo(){
    return(saldo);
};

float CcuentaGS::get_interes(){
    return(interes);
};

void CcuentaGS::set_saldo(float monto){
    saldo=monto;
};

void CcuentaGS::set_interes(float inte){
    interes=inte;
};

void CcuentaGS::deposito(float monto){
    saldo=saldo+monto;
};

void CcuentaGS::retirar(float monto){
    saldo=saldo-monto;
    if (saldo<0){
        negativo();
        saldo=saldo+monto;
    }
};

void CcuentaGS::consultar(){
    get_saldo();
};

void CcuentaGS::intereses(){
    float aux;
    aux= saldo*interes;
    std::cout<<"El interes es: "<<aux<<std::endl;
};

void CcuentaGS::negativo(){
    std::cout<<"La operacion no puede realizarse"<<std::endl;
};

#endif
