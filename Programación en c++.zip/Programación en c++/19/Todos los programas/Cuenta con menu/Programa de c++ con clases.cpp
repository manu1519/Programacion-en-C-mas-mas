#include <iostream>
#include "Otro header de menu.hpp"
using namespace std;

int main()
{
    CcuentaGS objeto;
    objeto.set_saldo(2000);
    objeto.set_interes(.02);
    C_MenuGS menu_obj(&objeto);
    menu_obj.menu();
    
          return 0;
        }


