#ifndef _CCUENTA_ //If not defined
#define _CCUENTA_

#include <iostream>
using namespace std;

class CCuenta
{
public: //Privacidad de los atributos
 float saldo;
 float interes;      
public: //Privacidad de los m�todos
//Un constructor se llama exactamente igual que la clase
//Un constructor no tiene tipo, no es un void
 CCuenta(float sal, float inte);
 void Deposito(float monto);
 void Retiro(float monto);
 float Consultar();
 void Calcular_interes();
 void Negativo();
};
//Los m�todos de una clase tienen acceso a sus atributos
//Los m�todos de una clase se pueden llamar entre si
CCuenta::CCuenta(float sal,float inte) //Constructor
{
saldo=sal;
interes=inte;                       
};

void CCuenta::Deposito(float monto) //Deposito que pertenece a CCuenta
{
saldo+=monto;     
};

void CCuenta::Retiro(float monto)
{
saldo-=monto;
 if(saldo<0)
 {
 Negativo();
 saldo+=monto;
 }
};

float CCuenta::Consultar()
{
return(saldo);      
};

void CCuenta::Calcular_interes()
{
float aux;
aux=saldo*interes;
cout<<"El interes es "<<aux<<endl;
};

void CCuenta::Negativo()
{
cout<<"La transaccion no puede realizarse"<<endl;     
};

#endif //End if
