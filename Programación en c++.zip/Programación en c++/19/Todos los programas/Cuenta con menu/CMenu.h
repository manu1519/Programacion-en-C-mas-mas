#ifndef _CMENU_H_//Apuntador: Variable que tiene un tipo, paso por valor,por referencia(la direccion del objeto se pasa)
#define _CMENU_H_//CMenu es el constructor
#include "CCuenta.h"//Aqui se llama
class CMenu{
	public: 
	char opc;
	CCuenta *obj; //Se recibe la direccion de memoria del objeto
	float monto; //En las bibliotecas de la clase se tienen que mandar a llamar, asi no se puede darle valores                             
	public:
		CMenu(CCuenta *objeto);
		void menu();	
};


CMenu::CMenu(CCuenta *objeto){
	obj=objeto;
}
void CMenu::menu(){
	do{
		cout<<"Selecciona una opcion"<<endl;
		cout<<"1. Deposito"<<endl;
		cout<<"2. Retiro"<<endl;
		cout<<"3. Consulta"<<endl;
		cout<<"4. Calcular interes"<<endl;
		cout<<"5. Salir"<<endl;
		cin>>opc;
		switch(opc){
			case '1':
			cout<<"Cuanto depositas?"<<endl;
			cin>>monto;
			obj->Deposito(monto);	
			break;
			
			case '2':
			cout<<"Cuanto retitas?"<<endl;
			cin>>monto;
			obj->Retiro(monto);	
			break;
			
			case '3':
			cout<<"El saldo es: "<<obj->Consultar()<<endl;
			break;
			
			case '4':
			obj->Calcular_interes();
			break;
			
			case '5':
			break;
			
			default:
			cout<<"Esa opcion no existe"<<endl;
		
	};
			
		
	}while(opc!=5);
};
#endif
