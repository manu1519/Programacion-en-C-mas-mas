//
//  Otro header de menu.hpp
//  Class
//
//  Created by Manuel Mendoza Meza on 4/4/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//
#ifndef _C_menuGS_H_
#define _C_menuGS_H_
#include "clase hoy.hpp"
#include <iostream>
using namespace std;
class C_MenuGS{
public:
    char opc;
    float monto;
    CcuentaGS *obj;
public:
    C_MenuGS(CcuentaGS *objeto){obj=objeto;};
    void menu();
    
};

void C_MenuGS::menu(){
    do{
        
        cout<<endl<<"Seleccione una opcion"<<endl;
        cout<<"1. Deposito"<<endl;
        cout<<"2. Retirar"<<endl;
        cout<<"3. Consultar"<<endl;
        cout<<"4. Calcular interes"<<endl;
        cout<<"5. Salir"<<endl;
        cin>>opc;
        
        switch(opc){
            case '1':
                cout<<"Cuanto deposita"<<endl;
                cin>>monto;
                obj->deposito(monto);
                break;
            case '2':
                cout<<"Cuanto retiras"<<endl;
                cin>>monto;
                obj->retirar(monto);
                break;
            case '3':
                cout<<"El saldo es:"<<obj->get_saldo()<<endl;
                break;
            case '4':
                obj->intereses();
                break;
            case '5':
                break;
            default:
                cout<<"&%$·$Opcion invalida"<<endl;
        }
    }
    
    while(opc!='5');
    
};

#endif /* C_menu_hpp */

