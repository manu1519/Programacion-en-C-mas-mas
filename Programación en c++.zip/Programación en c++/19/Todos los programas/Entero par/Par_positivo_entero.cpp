//  Mendoza Meza Manuel Everardo
//
//  Programa que permite encontrar un numero par cualquiera una vez ingresado
//
//  Analisis y diseño de programas
//  Programa: Par positivo entero


#include<iostream>

using namespace std;

int main()
{
float x;
int y;
    
    cout<<"Ingrese un numero: "<<endl;
    cin>>x;
    y=x;
    
    if((x-y)==0 && (x>0) && (y%2==0)){
        
    cout<<"El numero es entero, positivo y par"<<endl;
        
    }
    
    else{
        
    cout<<"No las cumple"<<endl;
        
	}
   
    system("PAUSE");
    return 0;
}
