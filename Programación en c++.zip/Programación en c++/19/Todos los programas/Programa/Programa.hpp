//  Mendoza Meza Manuel Everardo
//
//  Programa que permite a traves de clases generar valores predeterminados
//  en el constructor y mostrarlos en pantalla ocupando de la herencia
//  en POO
//
//  Analisis y diseño de programas
//  Programa: Hola mundo
//
//  Created by Manuel Mendoza Meza on 5/1/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.

#ifndef Programa_hpp
#define Programa_hpp

#include <iostream>
#include <stdio.h>

using namespace std;

class Programa{
private:
    string Titulo;
    string Genero;
public:
    Programa(string, string);
    void set_Titulo();
    void set_Genero();
    string get_Titulo();
    string get_Genero();
};
class Serie : public Programa {
private:
    int Temporadas;
    string Creador;
public:
    Serie(string, string, int, string);
    void set_Temporadas();
    void set_Creador();
    int get_Temporadas();
    string get_Creador();
    void Visualizar();
};
class Noticiero : public Programa{
private:
    string Horario;
    string Conductor;
public:
    Noticiero(string, string, string, string);
    void set_Horario();
    void set_Conductor();
    string get_Horario();
    string get_Conductor();
    void visualizar();
};

//------------------------Constructures

Programa::Programa(string _Titulo, string _Genero){
    Titulo=_Titulo;
    Genero=_Genero;
};

Serie::Serie(string _Titulo, string _Genero, int _Temporadas, string _Creador) : Programa(_Titulo, _Genero){
    Temporadas=_Temporadas;
    Creador=_Creador;
};

Noticiero::Noticiero(string _Titulo, string _Genero, string _Horario, string _Conductor) : Programa(_Titulo, _Genero){
    Horario=_Horario;
    Conductor=_Conductor;
};

//------------------------fin Constructores

//------------------------getters y setters de Programa
string Programa::get_Titulo(){
    return(Titulo);
};
string Programa::get_Genero(){
    return(Genero);
};
void Programa::set_Titulo(){
    cout<<"Nombre del Titulo: "<<Titulo<<endl;
};
void Programa::set_Genero(){
    cout<<"Genero: "<<Genero<<endl;
    
};
//------------------------getters y setters de Temporadas
int Serie::get_Temporadas(){
    return (Temporadas);
};

string Serie::get_Creador(){
    return (Creador);
};

void Serie::set_Temporadas(){
    get_Temporadas();
};

void Serie::set_Creador(){
    get_Creador();
};

void Serie::Visualizar(){

    cout<<"Temporadas: "<<Temporadas<<endl;
    cout<<"Creador: "<<Creador<<endl;
};

//------------------------getters y setters de Noticiero

string Noticiero::get_Horario(){
    return(Horario);
};
string Noticiero::get_Conductor(){
    return (Conductor);
};

void Noticiero::set_Horario(){
    get_Horario();
};

void Noticiero::set_Conductor(){
    get_Conductor();
};

void Noticiero::visualizar(){

    cout<<"Horario: "<<Horario<<endl;
    cout<<"Conductor: "<<Conductor<<endl;
};
#endif /* Programa_hpp */
