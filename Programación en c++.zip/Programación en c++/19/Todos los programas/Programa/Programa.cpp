//  Mendoza Meza Manuel Everardo
//
//  Programa que permite a traves de clases generar valores predeterminados
//  en el constructor y mostrarlos en pantalla ocupando de la herencia
//  en POO
//
//  Analisis y diseño de programas
//  Programa: Hola mundo
//
//  Created by Manuel Mendoza Meza on 5/1/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.

#include "Programa.hpp"
int main(){
    
    Programa pro( "Clases de terror", "Terror");
    pro.set_Titulo();
    pro.set_Genero();
    
    Serie ser(" ", " ", 8, "Philip J. Fry");
    ser.Visualizar();
    
    Noticiero no(" ", " ", "Vespertino", "Pedrito solar");
    no.visualizar();
 
    system("Pause");
    return 0;
}
