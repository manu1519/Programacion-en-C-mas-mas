//
//  Otro ejemp.cpp
//  Otro ejemplo
//
//  Created by Manuel Mendoza Meza on 4/30/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include "ejer.hpp"
int main (){
    
    Password pass;
    pass.generarPassword();
    pass.Nivel();
    system("pause");
    return 0;
    

}

