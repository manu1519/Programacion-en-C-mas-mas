//
//  ejer.hpp
//  Ejercicio
//
//  Crear un programa que genere una contraseña de 8 digitos numericos aleatorios
//  marcando repeticion, secuencia e inicios de 0 y 1 los cuales evaluan si es
//  de alto nivel o bajo nivel
//
//  Created by Manuel Mendoza Meza on 4/30/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef ejer_hpp
#define ejer_hpp

#include <stdio.h>
#include <iostream>
#include <time.h>
#include <cstdlib>
#include <ctime>

using namespace std;

class Password{
    
private:
    int longitud;
    int contrasena[9];
    
public:
    Password(){};
    void generarPassword();
    void Nivel();
    int get_longitud();
    int get_contrasena();
    void set_longitud(int longitud);
    
};

void Password::generarPassword(){
    int i;
    srand(time(NULL));
    for(i=0;i<8;i++)
    {
        contrasena[i]=1+rand()%(9-1);
        cout<<contrasena[i];
    }
    cout<<endl;
};

int Password::get_longitud(){
    return longitud;
};

int Password::get_contrasena(){
    return contrasena[8];
};

void Password::Nivel(){
    int f;
    bool a=true;
    bool ax=false;
    //---------------------Para valor inicial 0 o 1
    if (contrasena[0]==a||contrasena[0]==ax){
        f=1;
        cout<<"Su contraseña es de bajo nivel"<<endl;
    }
    else{
        f=0;
        cout<<"Su contraseña es de alto nivel"<<endl;
    }
    //-----------------------------------------------
    //----------------------Para numeros consecutivos
    int i,j,e;
    for (i=0;i<8;i++){
        if (contrasena[i]+1 == contrasena[i+1]){
            e=0;
            if (e){
                cout<<"Su contraseña es de bajo nivel"<<endl;
            }
            else{
                cout<<"Su contraseña es de alto nivel"<<endl;
            }
        }
    }
        //-----------------------------------------------
        //----------------------Para numeros repetidos
            for (j=i+1;j<8;j++){
            if (contrasena[i] == contrasena[j]){
                cout<<"Su contraseña es de bajo nivel"<<endl;
            }
            else{
                cout<<"Su contraseña es de alto nivel"<<endl;
            }
        }

    };
#endif /* ejer_hpp */
