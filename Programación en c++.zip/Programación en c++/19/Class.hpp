//
//  Class.hpp
//  
//
//  Created by Manuel Mendoza Meza on 4/2/19.
//

#ifndef Class_hpp
#define Class_hpp

#include <stdio.h>

#endif /* Class_hpp */
