//
//  main.cpp
//
//  arreglos para hacer matrices
//  Created by Manuel Mendoza Meza on 3/14/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>
using namespace std;
int main() {
    int a[5][5];
    int b=0;
    for (int i=0; i<5; i++) {
        for (int j=0; j<5; j++){
            cout<<"Ingrese el valor para" <<i+1<<","<<j+1<<":"<< endl;
        cin>>a[i][j];
            if (a[i][j]%2==0)
                b+=a[i][j];
        }
        
    }
    cout<<"La suma total de numeros pares es: "<<b<<endl;
    return 0;
}
