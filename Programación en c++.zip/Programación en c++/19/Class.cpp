//
//  Class.cpp
//  
//
//  Created by Manuel Mendoza Meza on 4/2/19.
//

#include "Class.hpp"
