//
//  Bebida.cpp
//  Examen
//
//  Programa que permite desglosar un menu de un almacen, donde se puede
//  Registrar productos, eliminar, visualizar, hacer suma de estanterias
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include "Menu.h"

int main(){
    
    Bebida opcion(float, float, string);
    Almacen opcion(int, string , int , float , int );
    Menu me;
    me.set_menu();
    
    
    
    return 0;
}

