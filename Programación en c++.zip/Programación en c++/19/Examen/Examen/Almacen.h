//
//  Almacén.h
//  Examen
//
//  Con este Header, se van almacenando, los datos introducidos en el header menu, ademas
//  se hace una operacion de suma y regresa el valor 
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Almace_n_h
#define Almace_n_h


#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>


using namespace std;

class Almacen {

public:
    /*Beb_azucarad*/    est_1[10];
    /*Agua*/            est_2[10];
    /*Agua_mineral*/    est_3[10];
    float sum_e1;
    float sum_e2;
    float sum_e3;
    float S_total;
    float IndiceAn;
    float IndiceAm;
    float IndiceAa;
    
    
public:
    Almacen(){};
    void menu();
    float suma_estan();
    void suma_total();
};

void Almacen::menu(){
    char opc, opc2;
    string marc, ID, origen;
    float precio, litro, precio_azu;
    int sodi;
    do{
        cout<<"Bienvenido a Almacenes MTC"<<endl;
        cout<<"Seleccione una opción: "<<endl;
        cout<<"A. Alta"<<endl;
        cout<<"B. Baja"<<endl;
        cout<<"C. Mostrar"<<endl;
        cout<<"D. Suma estanteria"<<endl;
        cout<<"E. suma total"<<endl;
        cin>>opc;
        switch (opc) {
            case 'A':
            case 'a':
                do{
                    cout<<"1. Agua Natural"<<endl;
                    cout<<"2. Agua Mineral"<<endl;
                    cout<<"3. Agua Azucaradas"<<endl;
                    cin>>opc2;
                    switch (opc2) {
                        case '1':
                            cout<<"Dame marca"<<endl;
                            cin>>marc;
                            cout<<"Dame precio"<<endl;
                            cin>>precio;
                            cout<<"Dame litros"<<endl;
                            cin>>litro;
                            cout<<"Dame ID"<<endl;
                            cin>>ID;
                            est_2[IndiceAn].agregar(marc, precio, litro, ID, so);
                            IndiceAm++;
                            break;
                            
                        default:
                            break;
                    }
                }
                break;
                
            default:
                break;
        }
    }
};

#endif /* Almace_n_h */
