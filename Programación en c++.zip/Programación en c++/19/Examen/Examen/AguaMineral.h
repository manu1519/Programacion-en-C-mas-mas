//
//  Agua Mineral.h
//  Examen
//
//  Este Header permite desglosar los atributos de la clase Agua mineral la cual es una subclase
//  de la clase Bebida

//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Agua_Mineral_h
#define Agua_Mineral_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Bebida.h"
using namespace std;

class Aguamin : public Bebida
{
private:            //-----atributos
    int Manantial;
public:             //-----metodos
    Aguamin(float, float, string, int);
    int get_Manantial();
    void set_Manantial();
};

Aguamin::Aguamin(float _CantL, float _Preci, string _Marc, int _Manantial) : Bebida (_CantL, _Preci, _Marc){
    Manantial=_Manantial;
};

int Aguamin::get_Manantial(){
    return (Manantial);
};

void Aguamin::set_Manantial(){
    string X;
    cout<<"Coloque el manantial o en su defecto donde fue extraida el agua"<<endl;
    cin>>X;
};
#endif /* Agua_Mineral_h */
