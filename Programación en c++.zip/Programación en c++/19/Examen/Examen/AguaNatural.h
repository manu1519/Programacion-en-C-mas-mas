//
//  Agua Natural.h
//  Examen
//
//  Este Header permite desglosar los atributos de la clase Agua natural la cual es una subclase
//  de la clase Bebida
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Agua_Natural_h
#define Agua_Natural_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Bebida.h"

using namespace std;

class Aguan : public Bebida{
private:                //------Atributos
    char Sodio;
public:                 //------Metodos
    Aguan(){};
    void agregar();
    void eliminar();
    char mostrar();
    int get_Sodio();
    void set_Sodio();
};

void Aguan::agregar(string x, float _Lt, float _pre, string _M, char _so){
    set_sodio(so);
    set_ID(x);
    set_litros
};

void Aguan::set_Sodio(){
    int S;
    cout<<"Coloque: "<<endl<<"0. Su bebida contiene sodio"<<endl<<"1. Su bebida contiene sodio"<<endl;
    cin>>S;
};

#endif /* Agua_Natural_h */
