//
//  Agua Azu.h
//  Examen
//
//  Este Header permite desglosar los atributos de la clase Agua Azucarada la cual es una subclase
//  de la clase Bebida
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Agua_Azu_h
#define Agua_Azu_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Bebida.h"
using namespace std;

class AguaA : public Bebida{
private:            //-----atributos
    float Azucar;
public:             //-----metodos
    AguaA(float, float, string, int, float);
    float get_Azucar();
    void set_Azucar();
};

AguaA::AguaA(float _CantL, float _Preci, string _Marc, float _Azucar) : Bebida (_CantL, _Preci, _Marc){
    Azucar=_Azucar;
};
float AguaA::get_Azucar(){
    return (Azucar);
};

void AguaA::set_Azucar(){
    float g;
    float res;
    cout<<"Ingrese gramos de azucar: "<<endl;
    cin>>g;
    res=g/4;
    cout<<"El porcentaje de azucar en su bebida es: "<<res<<endl;
};
#endif /* Agua_Azu_h */
