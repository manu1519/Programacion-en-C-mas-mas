//
//  Bebida.hpp
//  Examen
//
//  En este header se pueden ver los atributos, cantidad de litros, precio y marca
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Bebida_hpp
#define Bebida_hpp
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>


class Bebida{
private:    //-------Atributos
    string ID;
    float CantL;
    float Preci;
    string Marc;
public:     //-------Metodos

    Bebida();
    float get_CantL();
    float get_Preci();
    string get_Marc();
    string get_ID();
    string set_ID();
    void set_CantL();
    void set_Preci();
    void set_Marc();
    void Mostrar();
};
class Aguan : public Bebida{
private:                //------Atributos
    char Sodio;
public:                 //------Metodos
    Aguan(){};
    void agregar(string, float, float, string);
    void eliminar();
    char mostrar();
    int get_Sodio();
    void set_Sodio();
};

void Aguan::agregar(string x, float _Lt, float _pre, string _M, char _so){
    set_Sodio(so);
    set_ID(x);
    set_CantL(Lt);
    set_Marc(M);
    set_Preci(pre);
};
//---------------getters
float Bebida::get_CantL(){
    return (CantL);
};
float Bebida::get_Preci(){
    return (Preci);
};
string Bebida::get_Marc(){
    return (Marc);
};
string Bebida::get_ID(){
    return (ID);
};
//-------------fin getters

//-------------setters
void Bebida::set_ID(){
    return=ID;
};


void Bebida::set_CantL(float b){
    CantL=b;
};

void Bebida::set_Preci(){
    int l;
    cout<<"Ingrese el precio: "<<endl;
    cin>>l;

};

void Bebida::set_Marc(){
    string M;
    cout<<"Ingrese la marca: "<<endl;
    cin>>M;
    
};
#endif /* Bebida_hpp */

