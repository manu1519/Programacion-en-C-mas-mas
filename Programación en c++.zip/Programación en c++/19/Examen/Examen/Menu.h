//
//  Menu.h
//  Examen
//
//  Header menu, donde se unen todas las opciones del programa y se desglosa un menu para el usuario
//
//  Created by Manuel Mendoza Meza on 5/2/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef Menu_h
#define Menu_h

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include "Almacen.h"
#include "Bebida.h"

using namespace std;

class Menu{
    
private:                //-----Atributos
    
string menu;
Almacen *obje;
    Bebida *obj;
    string r;
    char C;
    int p[20], n[30], i;
public:                 //------metodos
    Menu(Bebida *objeto){obj=objeto;};
    Menu(){};
   Menu(Almacen *objeto1){obje=objeto1;};
    char opc, op;
    string get_menu();
    void set_menu();
};

string Menu::get_menu(){
    return (menu);
};
void Menu::set_menu(){
    char opcion[10];
    
    
        system("cls");
        cin.clear();
        cout<<"Bienvenido a Almacenes MTC"<<endl;
        cout<<"Seleccione una opción: "<<endl;
        cout<<"A. Almacen"<<endl;
        cout<<"B. Salir"<<endl;
        cin>>C;
        switch (C) {
        
            case 'a':
            case 'A':
            
                cout<<"Seleccione una opción: "<<endl;
                cout<<"1. Agregar producto"<<endl;
                cout<<"2. Eliminar producto"<<endl;
                cout<<"3. Visualizar productos"<<endl;
                cout<<"4. Sumar"<<endl;
                cout<<"5. salir"<<endl;
                cin>>opcion;
                //do{
                switch (opcion[0]) {
                    case '1':
                    a:
                        for (i=0;i<9;i++){
                        cout<<"("<<i+1<<")"<<"Ingresa ID: "<<endl;
                        cin>>p[i];
                           
                            cout<<"("<<i+1<<")"; obj->set_Marc();
                           
                        cout<<"("<<i+1<<")"<<"Ingresa la cantidad: "<<endl;
                        cin>>n[i];
                  
                            cout<<"("<<i+1<<")"; obj->set_CantL();
                            
                            cout<<"("<<i+1<<")"; obj->set_Preci();
                           /*  cout<<"¿Desea Continuar con ingresar?"<<" S=Si"<<" N=No"<<endl;
                            cin>>pt;
                           
                           switch (pt) {
                                case 'S':
                                case 's':
                                    goto a;
                                    break;
                                case 'n':
                                case 'N':
                                    goto re;
                            
                                default:
                                    break;
                            }*/
                            
                        }
                        return set_menu();
                        break;
                    case '2':
                        
                        break;
                    case '3':
                        for (int j=0; j<9; j++){
                           cout<<"("<<j++<<")"<<obj->get_Marc()<<endl;
                        }
                        break;
                    case '4':
                        
                        break;
                    case '5':
                        break;
                    default:
                        cout<<"Intente de nuevo porfavor"<<endl;
                        
                        break;
                }
                        //}while (10);
                
                
            case 'b':
            case 'B':
                break;
                
            default:
                cout<<"Intente de nuevo porfavor"<<endl;
                return (set_menu());
                break;
        }
    
                
        };
 
#endif /* Menu_h */

