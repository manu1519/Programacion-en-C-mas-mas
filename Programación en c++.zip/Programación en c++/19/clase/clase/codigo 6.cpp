//
//  main.cpp
//
//  programa que tome un 5 datos enteros y luego se suman
//  Created by Manuel Mendoza Meza on 3/14/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>
using namespace std;
int main(){
    
    int a[5],i;
    long b=0;
    
    for (i=0; i<5; i++){
        cout<<"Ingresa un valor"<<endl;
        cin>>a[i];
    b=b+a[i];
    }
    cout<<b<<"Es la suma"<<endl;
    return 0;
}
