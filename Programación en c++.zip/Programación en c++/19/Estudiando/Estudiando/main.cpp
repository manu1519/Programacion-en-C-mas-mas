//
//  main.cpp
//  Estudiando
//
//  Created by Manuel Mendoza Meza on 4/10/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>
#include <stdlib.h>
using namespace std;
class Rectangulo{
private:
    int largo;
    int ancho;
public:
    Rectangulo(int,int);
    void perimetro();
    void area();
};
Rectangulo::Rectangulo(int _largo, int _ancho){
    largo = _largo;
    ancho = _ancho;
}
void Rectangulo::perimetro(){
    int p;
    p=(2*largo)+(2*ancho);
    cout<<"El perimetro del rectangulo es: "<<p<<endl;
}
void Rectangulo::area(){
    int a;
    a= (largo*ancho);
    cout<<"El area del rectangulo es: "<<a<<endl;
}
using namespace std;
int main() {
    
    Rectangulo r1 (5,10);
    r1.perimetro();
    r1.area();
    
    return 0;
}
