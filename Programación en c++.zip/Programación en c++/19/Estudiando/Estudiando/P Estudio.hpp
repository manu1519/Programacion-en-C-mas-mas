//
//  P Estudio.hpp
//  Estudiando
//
//  Created by Manuel Mendoza Meza on 4/10/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#ifndef P_Estudio_hpp
#define P_Estudio_hpp
#include <stdio.h>
#include <iostream>
using namespace std;
class Tiempo{
public:
    int horas, minutos, segundos;
public:
    Tiempo(int,int,int);
    void mostrartiempo();
    Tiempo(int);
};
Tiempo::Tiempo(int _h, int _min, int _seg){
    horas=_h;
    minutos=_min;
    segundos=_seg;
}
Tiempo::Tiempo(int segu){
    horas= segu/3600;
    segu %= 3600;
    minutos= segu/60;
    segundos= segu%60;
}

void Tiempo::mostrartiempo(){
    cout<<"El tiempo es: "<<horas<<" h "<<minutos<<" min "<<segundos<<" seg"<<endl;
}
#endif /* P_Estudio_hpp */
