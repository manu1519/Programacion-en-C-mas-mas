//
//  P Estudio.cpp
//  Estudiando
//
//  Created by Manuel Mendoza Meza on 4/10/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "P Estudio.hpp"
using namespace std;
int main(){
    
    Tiempo hor(22,30,45);
    hor.mostrartiempo();
    Tiempo otro(15600);
    otro.mostrartiempo();
    
    return 0;
}
