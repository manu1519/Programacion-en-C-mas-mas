//
//  main.cpp
//  uso de if
//  reduccion de codigo valor entero positivo
//  Created by Manuel Mendoza Meza on 3/12/19.
//  Copyright © 2019 Manuel Mendoza Meza. All rights reserved.
//

#include <iostream>
using namespace std;

int main() {
   
    float a;
    int b;

    do{
        cout<<"Dame el dato"<<endl;
        cin>>a;
        b=a;
        
    }while(!((a-b)==0 && (a>0) && (b%2==0)));
    
    return 0;
}
